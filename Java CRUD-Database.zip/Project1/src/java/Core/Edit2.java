package Core;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Edit2 extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Edit2</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Edit2 at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
          
   
        String firstname=request.getParameter("firstname");  
        String surname=request.getParameter("surname");  
        String university=request.getParameter("university");  
        String ssemester=request.getParameter("semester");
        int semester=Integer.parseInt(ssemester);
        String spassed=request.getParameter("passed");
        int passed=Integer.parseInt(spassed);
          
        Student student = new Student();  
        student.setFirstname(firstname);  
        student.setSurname(surname);  
        student.setUniversity(university);  
        student.setSemester(semester);  
        student.setPassed(passed);  
          
        int status=StudentDao.update(student);  
        if(status>0){  
            response.sendRedirect("ViewServlet");  
        }else{  
            out.println("Sorry! unable to update record");  
        }  
          
        out.close();
    
        processRequest(request, response);
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

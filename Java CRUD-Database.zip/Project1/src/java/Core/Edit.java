package Core;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Edit extends HttpServlet {

 
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Edit</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Edit at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");  
        try (PrintWriter out = response.getWriter()) {
            out.println("<h1>Update Student</h1>");
            String surname=request.getParameter("surname");
            
            Student student = StudentDao.getStudentBySur(surname);
            
            out.print("<form action='EditServlet2' method='post'>");
            out.print("<table>");
            out.print("<tr><td></td><td><input type='hidden' name='firstname' value='" + student.getFirstname() + "'/></td></tr>");
            out.print("<tr><td>Surname:</td><td><input type='text' name='surname' value='" + student.getSurname() + "'/></td></tr>");
            out.print("<tr><td>University:</td><td><input type='text' name='university' value='" + student.getUniversity() + "'/></td></tr>");
            out.print("<tr><td>Semester:</td><td><input type='number' name='semester' value='" + student.getSemester() + "'/></td></tr>");
            out.print("<tr><td>Passed:</td><td><input type='number' name='passed' value='" + student.getPassed() + "'/></td></tr>");
            out.print("<tr><td>Country:</td><td>");
            out.print("</td></tr>");
            out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
            out.print("</table>");
            out.print("</form>");
        }
        processRequest(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

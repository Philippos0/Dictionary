package Core;

import java.util.List;

/*import java.io.Serializable;*/

public class Student {

    public static List<Student> getAllStudents() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private String firstname;
    private String surname;
    private String university;
    private int semester;
    private int passed;
    
    public Student(){   
    }
    public Student(String firstname,String surname,String university, int semester,int passed){
        this.firstname=firstname;
        this.surname=surname;
        this.university=university;
        this.semester=semester;
        this.passed=passed;
    }
        
        
    public String getFirstname() {
    return firstname;
    }
        
    public void setFirstname(String firstname) {
    this.firstname = firstname;
    }
    
    public String getSurname() {
    return surname;
    }
    
    public void setSurname(String surname) {
    this.surname = surname;
    }
    
    
    public String getUniversity() {
    return university;
    }
    
    public void setUniversity(String university) {
    this.university = university;
    }
    
    public int getSemester() {
    return semester;
    }
    
    public void setSemester(int semester) {
    this.semester = semester;
    }
    
    public int getPassed() {
    return passed;
    }
    
    public void setPassed(int passed) {
    this.passed = passed;
    } 
     
}


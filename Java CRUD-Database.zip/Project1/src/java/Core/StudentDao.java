package Core;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class StudentDao {
    
    public static Connection getConnection(){
        Connection con=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/askisi1_db", "philip", "");
            
        }catch(ClassNotFoundException | SQLException e){
    }
    return con;
}
    
public static int save(Student student){
   int status = 0;
        Connection con = StudentDao.getConnection();
        try {
            PreparedStatement ps = con.prepareStatement("INSERT INTO students VALUES (?, ?, ?, ?, ?)");
            ps.setString(1,student.getFirstname());  
            ps.setString(2,student.getSurname());  
            ps.setString(3,student.getUniversity());  
            ps.setInt(4,student.getSemester());
            ps.setInt(5,student.getPassed()); 
            status=ps.executeUpdate();                
            con.close();
        } catch (SQLException ex) {            
        }
        return status;
}
 public static int update(Student student) {
        int status = 0;
        Connection con = StudentDao.getConnection();
        try {
            PreparedStatement ps = con.prepareStatement("UPDATE student SET firstname=?, surname=?, university=?, semester=?, passed=? WHERE surname=?");
            ps.setString(1,student.getFirstname());  
            ps.setString(2,student.getSurname());  
            ps.setString(3,student.getUniversity());  
            ps.setInt(4,student.getSemester());
            ps.setInt(5,student.getPassed()); 
             ps.setString(6,student.getSurname()); 
            
            status=ps.executeUpdate();                
            con.close();
        } catch (SQLException ex) {            
        }
        return status;
    }
        
public static int delete(String surname) {
        int status = 0;
        Connection con = StudentDao.getConnection();
        try {
            PreparedStatement ps = con.prepareStatement("DELETE FROM students WHERE surname=?");
            ps.setString(1, surname);
            status=ps.executeUpdate();                
            con.close();
        } catch (SQLException ex) {            
        }
        return status;
    }

 public static Student getStudentBySur(String surname) {
        Student student = new Student();
        Connection con = StudentDao.getConnection();        
        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM students WHERE surname=?");
            ps.setString(1,surname);  
            ResultSet rs = ps.executeQuery();  
            if(rs.next()){  
                student.setFirstname(rs.getString(1));  
                student.setSurname(rs.getString(2));  
                student.setUniversity(rs.getString(3));  
                student.setSemester(rs.getInt(4));  
                student.setPassed(rs.getInt(5));  
            }  
            con.close();  
        } catch (SQLException ex) {            
        }
        return student;
    }

public static List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        Connection con = StudentDao.getConnection();  
        
        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM students");
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
                Student student = new Student();  
                student.setFirstname(rs.getString(1));  
                student.setSurname(rs.getString(2));  
                student.setUniversity(rs.getString(3));  
                student.setSemester(rs.getInt(4));  
                student.setPassed(rs.getInt(5));  
                list.add(student);  
            }  
            con.close(); 
        } catch (SQLException ex) {
            
        }
        return list;
    }
}
